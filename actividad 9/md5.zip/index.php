<html lang="es">
<head>
	<title>Ivan</title>
</head>
<body>
<h1>MD5 cracker</h1>
<p>This application takes an MD5 hash of a four digit pin and check all 10,000 possible four
digit PINs to determine the PIN.
</p>
<form>
<input type="text" name="md5" size="60" />
<input type="submit" value="Crack MD5"/>
</form>
<?php 

$md5 = $_GET['md5'];
$tiempo = microtime(true);
$contador = -1;
$checks = 0;
    
    do{
       
        $checks++;
        $contador++;
        $resultado = hash('md5',$contador);
        if($contador < 15){
            
            echo "<pre>" . $resultado . " " . str_pad($contador,4,0,STR_PAD_LEFT) . "</pre>" ;
        }
        
    }while($resultado != $md5 && $contador < 10000 );
    
    $finTiempo = microtime(true);
    $tiempoTotal = $finTiempo - $tiempo;
    
    echo "<p><b>Total checks</b></p>" . $checks;
    echo "<p><b>Ellapsed time</b></p>" . $tiempoTotal;
    
    if($contador >= 10000){
        
        echo "<h3>PIN no encontrado</h3>";
    }else {
        
        echo "<h3>PIN</h3>" . "<pre>" . " " . str_pad($contador,4,0,STR_PAD_LEFT) . "</pre>";
    }
   
    
?>

</body>
</html>